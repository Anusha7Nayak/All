export class Item {
  _id?: string;
  itemname: String;
  itemquantity: Number;
  itembought: Boolean;
}
