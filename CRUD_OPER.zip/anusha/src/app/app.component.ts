import { Component } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ItemServiceService } from './service/item-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

constructor(private itemService:ItemServiceService,
  private formbuilder:FormBuilder,private router:Router){

}
ngOnInit() {
 
}
 // title = 'angularFrontend';


}
