import { Component, OnInit } from '@angular/core';
import { Item } from 'src/app/model/item';
import { ItemServiceService } from 'src/app/service/item-service.service';


@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {
  shoppingitemlist: Item[];
  toggleForm: 
  Boolean = false;
  selectedItem: Item;
  constructor(private itemService: ItemServiceService) {
  }
  ngOnInit() {

    this.getitems();
  }
getitems(){
  this.itemService.getshoppingitem().subscribe(items=>{
    this.shoppingitemlist=<Item[]>items;
  })
}
//Templatedrivenform
addItem(frm){
  console.log(frm.value);
  let newitem:Item={
    itemname:frm.value.itemname,
    itemquantity:frm.value.itemquantity,
    itembought:false
  }
  this.itemService.addshoppingitem(newitem).subscribe(item=>{
    console.log(item);
    this.getitems();
  })
}

editForm(editfrm) {
let newItem: Item = {
  _id:this.selectedItem._id,
  itemname:editfrm.value.itemname,

  itemquantity:editfrm.value.itemquantity,
  
  itembought:this.selectedItem.itembought
  }
  
  this.itemService.updateshoppingitem(newItem).subscribe(result=> {
  console.log('original item to be updated with old values' +result);
  this.getitems();
  this.toggleForm = !this.toggleForm;
  })
  }
  
  showEditform(Item) {
  
  this.selectedItem =Item;
  this.toggleForm = !this.toggleForm;
 
  }
  updateItemcheckbox(item) {
  
  item.itemboughts = !item.itemboughts;
  
  this.itemService.updateshoppingitem(item).subscribe(result=> {
  
  // console.log('Original CheckBox values' + result.itemboughts);
  
   //item.getItems();
  })
  
  }

deleteItem(it:Item):void {

  let result =  confirm("do you really want to delete the task?")
  
  if(result){
  
  this.itemService. deleteshoppingItem(it._id).subscribe(data=>{
  
  this.shoppingitemlist=this.shoppingitemlist.filter(u=>u!==it);
  
  });
  
  } 
  
  }

}
