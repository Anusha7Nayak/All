
var b=new Buffer(10);
var noofbyteswritten=b.write('This is my sample buffer');
console.log("bytes written" +noofbyteswritten);
console.log(b.toString());

