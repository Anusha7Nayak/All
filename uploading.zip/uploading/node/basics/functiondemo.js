function helloworld(hello){
    console.log("welcome to"+ hello);
}
// call helloworld function
helloworld("Hello World");