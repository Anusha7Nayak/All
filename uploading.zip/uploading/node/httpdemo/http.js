var http = require("http");
var server = http.createServer(function(request, res) 
{
    res.writeHead(200, {"Content-Type": "text/plain"});
res.write("Hello world");
res.end();
}).listen(7777);
console.log("server is running on 7777");