var bcrypt = require('bcrypt');



var hash =bcrypt.hashSync('rashmi',bcrypt.genSaltSync(12));

console.log(hash);



var v=bcrypt.compareSync('rashmi',hash);

console.log("returns " +v);

var v =bcrypt.compareSync('rashmi',hash);

console.log("returns " +v);


