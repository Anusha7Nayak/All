const express=require('express');
const path=require('path');
//initialize the app object
const app=express();
//load the view
app.set('views',path.join(__dirname,"views"));
console.log(__dirname);
app.set("view engine","pug");
//defining routes
app.get('/',function(req,res){
    let emp=[
        {
            empid:1001,
            empname:'rashmi',
            empdep:"IT",
            empsalary:1000
        },
        {
            empid:1002,
            empname:'Viju',
            empdep:"IT",
            empsalary:3000
        }
    ];
    res.render('index',{
       title:'this is my page',
       empData:emp
    });

});//get close
// create another route as home
app.get('/home', function(req,res){
res.render('home',{
mydata:'this is my data from home'
});

});//get close
app.listen(5000,function(){
    console.log("server is started on port 5000");
});