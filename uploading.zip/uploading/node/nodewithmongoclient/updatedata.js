var mongodb=require('mongodb');

var MongoClient=mongodb.MongoClient;
var url='mongodb://localhost/mobile';
MongoClient.connect(url,function(err,client){
if(err){
    console.log(err);
}else{
   
    var db=client.db('mobile');
    var collection=db.collection('mobiledata');
   
    collection.update({'mobid':100},{$set:{'mobilename':'samsung','mobilecost':7000}},function(err,res){
if(err){
    console.log(err);
}else{
    console.log('Updated Data...'+res);
}
    });
   
}
});