var hello={
    getData:function() {
        console.log("In get data");
    
    },
    getLogin:function() {
  console.log("in Get login");
    }
};
module.exports=hello;