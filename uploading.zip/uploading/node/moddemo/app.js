var mod1= require("./mode1.js");
mod1.getData();
mod1.getLogin();

console.log(mod1.getData());
console.log(mod1.getLogin());
