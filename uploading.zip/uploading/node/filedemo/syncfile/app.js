const fs=require ('fs');
fs.writeFileSync('input.txt',"Hello Akku",function(err){
    if(err)
    
        console.log(err);
    
    else
        console.log("write option is completed");
    
});
// sync operation is working
var data=fs.readFileSync('input.txt');
console.log("synchronous reading..." +data.toString());
console.log("program end");
