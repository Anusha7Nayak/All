const fsobj = require('fs');
fsobj.readFile('input.txt', function (err, data) {
    if (err) {
        console.log("problem reading file");
    }
    else {
        console.log("reading");
    }
    fsobj.writeFileSync('writeme.txt',data,function(err){
        if(err){
         return  console.log(err);
        }
    });

});
console.log("end")