var data=require('./lib/mod1');

data.emp();

data.pro("anu");

