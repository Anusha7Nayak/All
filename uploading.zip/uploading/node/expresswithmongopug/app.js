const express=require('express');
const path=require('path');
const mongoose=require('mongoose');
let Employee=require('./model/employee');
var bodyParser=require('body-parser')
//home
//connect to mongodb
mongoose.connect('mongodb://localhost/mypugdb');
let db=mongoose.connection;
db.once('open',function(){
    console.log('connection open')
});
db.on('error',function(err){
    console.log(err);
});
const app=express();
//load view engine
app.set('views',path.join(__dirname,'views'));
app.set('view engine','pug');
// parse application/x-www-form-urlencoded--For inserting
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json--For Inserting 


app.use(bodyParser.json());
//app routes
//index
app.get('/',function(req,res){
    Employee.find({},function(err,employeedata){
    res.render('index',{
        title:'This is capgemini L&D',
        empData:employeedata,
        emg:'L&D department'
    });
});
});

//home


//add route
app.get('/add',function(req,res){
    res.render('addEmployee',{
        mydata:'This is Capgemini L&D'
    });
});




app.post('/emp/adddata',function(req,res){
    let emp=new Employee();
emp.empid=req.body.eid;
emp.empname=req.body.ename;
emp.empdept=req.body.edep;
emp.empsalary=req.body.esal;
emp.save(function(err){
if(err){
    console.log(err);
    return;
}else
{
     res.redirect('/');
}
});

});

//delete data from mongodb

app.get('/deleteemp/:id',function(req,res){
    let queryDelete={_id:req.params.id};
    Employee.remove(queryDelete,function(err){
        if(err) {
            console.log(err);
            return;
        }
        else 
        {
            res.redirect('/');
        }
    });
});

//Search & then send for Update 
app.get('/searchemp/:id',function(req,res){
	Employee.findById(req.params.id,function(err,edata){
if(err){
	console.log(err);
}else{
	res.render('updateemployee',{
		data:edata
	});
}
	});
	
});
//Update the Mongo database
app.post('/emp/updatedata/:id',function(req,res){
	let emp={};
emp.empid=req.body.eid;
emp.empname=req.body.ename;
emp.empdept=req.body.edep;
emp.empsalary=req.body.esal;
	let query= {_id:req.params.id};
    //console.log(query);
	Employee.update(query,emp,function(err){
		if(err){
			console.log(err);
			return;
		}else{
			 res.redirect('/');
		}
	});
	});

//home
app.get('/home',function(req,res){
    res.render('home',{
        mydata:'this is from home'
    });
});

app.listen(1000,function(){
    console.log("port is running in 1000")
});
