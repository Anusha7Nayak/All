import React, { Component } from 'react'
import {incrementCount,decrementCount} from '../Actions/counteraction'
import { connect } from 'react-redux';

export class Counter extends Component {
   
  render() {
    const {count,incrementCount,decrementCount}=this.props;
    return (
      <div>
          <button onClick={()=>incrementCount()}>+</button>
          <span>{count}</span>
          <button onClick={()=>decrementCount()}>-</button>
        
      </div>
    )
  }
}
const mapStatetoProps=(state)=>({
    count:state
})
const mapDispatchToProps=(dispatch)=>({
    decrementCount:()=> dispatch(decrementCount()),
    incrementCount:()=> dispatch(incrementCount())
});
export default connect(mapStatetoProps,mapDispatchToProps)(Counter);

