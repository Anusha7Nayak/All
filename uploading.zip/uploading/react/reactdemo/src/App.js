import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router,Route, Link, Switch } from 'react-router-dom'
import {Welcome} from './components/welcome';
import {Funclassdemo} from './components/Funclassdemo';
import {Greeting} from'./components/greeting';
import {GreetClassComponent} from './components/greetclass'
import {NumListClassComponent} from './components/NumListClassComponent'
import {ListDemo} from './components/listdemo'
import {EventDemo} from './components/eventdemo'
import {Event1} from './components/event2'
import {StateDemo} from './components/statedemo'
import {State} from './components/statedemo2'
import {Homes} from './components/home'
import {About} from './components/about'
import {Header} from './components/header'
import {Form} from './components/form'
import {Form1} from './components/form1'
import {Form2} from './components/form2'
import {Ref} from './components/refdemo'
import CustomerInfo from './components/customer-info';
import LifecycleA from './components/lifecycleA';
import ViewContact from './components/viewcontact';
import Image from './components/img';
import Parent from './components/parentcomp';


class App extends Component {
  render() {
    let numbers=[11,22,33,44,55,66,77];
    let user={
      name:"Anusha",
      hobbies:["sports","swimming","music","watching movies","shopping"]
    }
    return (

<Router>

<div>
<Parent>
  <button> Click</button>
  <button> Add</button>

  <h1> This is an example</h1>
<br/>
  </Parent>
<Header/>

<div className="container">

<Switch>

<Route exact path="/" component={Homes}/>

<Route exact path="/about" component={About}/>
<Route exact path="/form" component={Form}/>
<Route exact path="/form1" component={Form1}/>
<Route exact path="/form2" component={Form2}/>
<Route exact path="/ref" component={Ref}/>
<Route exact path="/adddelete" component={CustomerInfo}/>
<Route exact path="/lifecycle" component={LifecycleA}/>
<Route exact path="/viewcontact" component={ViewContact}/>
<Route exact path="/img" component={Image}/>


</Switch>

</div>

</div>

</Router>
 
  
   
      )
    }
  }
   
//       // <div className="container">
//       // <div className="row">
//       // <div className="col-xs-12">
//      {/* <Greeting name="Anusha"/>
//      <Greeting name="Akshatha"/>
//      <Greeting name="Amitha"/> */}
//     //  <hr/>
//      /* <GreetClassComponent name="vijaylaxmi"/>
//      <GreetClassComponent name="Ramitha"/>
//      <GreetClassComponent name="Raksha"/> */
//      /* <NumListClassComponent numbers={numbers} />
//      <ListDemo name ={user.name}age={23}user={user}>
//      <h2> this is children text</h2>
//      <h2> this is children text</h2>
//      </ListDemo> */
//     /* <EventDemo/> */

//     //  <Event1 age={23}/> 
//     //  <StateDemo message="welcome Akku"/>
//     //  <State count={0}/>
  
//     //    </div>
//     //    </div>
//     //    </div>
// //  <div>
//       // {/* <h1> Hello welcome to my app</h1>
//       // <h1>This is another tag</h1> */}
//       // <Welcome/>
//       /* <Funclassdemo/> */
//       //<div>

     
      
   

export default App;
