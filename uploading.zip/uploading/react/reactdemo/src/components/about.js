import React  from 'react'

export class About extends React.Component {
    render() {
        return(
            <h1> Welcome to about component</h1>
        )
    }
}
export default About;