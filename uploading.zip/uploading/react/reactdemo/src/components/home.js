import React  from 'react'

export class Homes extends React.Component {
    render()
     {
        return(
            <div>
            <h1> Welcome to home component</h1>
            <img src={require('./prod1.jpg')}/>
            </div>
        )
    }
}
export default Homes;