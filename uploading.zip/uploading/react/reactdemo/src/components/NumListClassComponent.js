import React from 'react'

export class NumListClassComponent extends  React.Component {
    render(){
        return (
       
            <ul>
                {/* <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li> */}
                {this.props.numbers.map((n,i)=> <li>key={i}>{n}</li>)}
            </ul>
           
           
         
        )
    }

}
export default NumListClassComponent;