import React from 'react'
import {connect} from 'react-redux'

 function Counter(props) {
     console.log("render",props)
  return (
    <div align="center">
      <h1> I am a counter</h1>
      <p> Count={props.count}</p>
      <button onClick={props.onIncrementalClick}>Increment</button>

    </div>
  )
}

function mapStateToProps(state) {
    console.log("mapstatetoprops",state);
    return {
        count:state.count
    }
}
function mapDispatchToProps(dispatch){
    return {
        onIncrementalClick:()=>
        {
            console.log('clicking');
            const action={type:'INCREMENT'};
            dispatch(action);
        }
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Counter);