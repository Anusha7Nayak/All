import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Counter from './counter';
import store from './store/store';

class App extends Component {
  render() {
    return (
    <div>
      <Counter store={store}/>
    </div>
    );
  }
}

export default App;
