show dbs

use mydatabase
--create collection
db.createCollection("student" )
show dbs
show collections
db.student.drop()
--insert values
db.student.insert({
    "studentno":1,"firstname":"anu",
    "lastname":"nayak", "age":20,"dept":"IT","salary":1000, address:{
        street:"67MG road",
        city:"mumbai",
        state:"MS"
    }
})
db.student.insert({
    "studentno":5,"firstname":"anagha",
    "lastname":"nayak", "age":20,"dept":"sales","salary":7000
})
--find values
db.student.find()
--to insert many records in array
db.student.insertMany([
    {"studentno":2,"firstname":"akku",
    "lastname":"nayak", "age":23 ,"dept":"HRD","salary":2000,address:{
        street:"Indavara",
        city:"Thirthahalli",
        state:"Karnataka"
    }},
    {"studentno":3,"firstname":"amitha",
    "lastname":"nayak", "age":23,"dept":"IT","salary":3000,address:{
        street:"Thane",
        city:"mumbai",
        state:"MS"
    }},
    {"studentno":4,"firstname":"akku",
    "lastname":"nayak", "age":23,"dept":"sales","salary":4000,address:{
        street:"KG street",
        city:"mumbai",
        state:"MS"
    }}

    ])
    --find one only one record
    db.student.findOne({})
db.student.find({$or:[{"firstname":"akku"},{"age":20}]})
db.student.find({"firstname":/.u$/},{"firstname":1,"_id":0})
//22)limit skip
db.student.find({}).limit(2)
db.student.find({}).skip(2)
db.student.find({}).limit(2).skip(1)
//sorting
db.student.find({})
//desending
db.student.find({}).sort({"firstname":-1})
// 
db.student.find({}).sort({"studentno":1})
//update
db.student.update({"age":23},{$set: {"lastname":"Rao"}})
db.student.update({"studentno":2},{$set: {"age":20}})
db.student.update({"studentno":2},{$set: {"age":20}})
//multi lines true  for changing multiple lines 
db.student.update({"age":23},{$set: {"lastname":"Rao"}},{multi:true})
//unset
db.student.update({"age":20},{$unset:{"lastname":"Rao"}})
db.student.update({"age":20},{$set:{"lastname":"Rao"}})


//aggregation
db.student.aggregate([{$group:{	"_id" :"$dept",salary:{$max:"$salary"}}}])
//min 
db.student.aggregate([{$group:{	"_id" :"$dept",salary:{$min:"$salary"}}}])
//sum
db.student.aggregate([{$group:{	"_id" :"$dept",salary:{$sum:"$salary"}}}])
//avg
db.student.aggregate([{$group:{	"_id" :"$dept",salary:{$avg:"$salary"}}}])
// in 
db.student.find({"salary":{$in:[2000,3000,4000]}})
//upsert 
db.student.update({firstname:"ramya"},{lastname:"some",dept:"admin"},{upsert:true})

db.student.update({firstname:"anu"},{lastname:"some",dept:"admin"},{upsert:true})
db.student.find({"address.city":"mumbai"})

