use MediaDB
db.moviesCollections.insert(
    {
        title: "DDLJ",
        Description: "A young man and woman - both of Indian descent but born and raised in Britain - fall in love during a trip to Switzerland",
        Director: "Aditya Chopra",
        Rating: 4,
        MusicBy: "Jatin-Lalit",
        Awards: ["Filmfare", "National Award"],
        Cast: ["SRK", "Kajol", "Anupam Kher", "Amrish Puri"],
        SoundTrack: ["Ghar Aaja Pardesi", "Ho Gaya Hai Tujhko", "Mere Khwabon"],
        GeneralInfo: { ReleaseDate: "19Oct 1995", Duration: "120min", Rating: 4, ProductionCompany: "Yash Raj Films" },
        Genre: "Romantic",
        Reviews: [
            { ReviewerName: "Sachin", Comments: "Excellent", DateOfComment: "1/1/2011" },
            { ReviewerName: "Saurav", Comments: "Good", DateOfComment: "2/1/2011" },
            { ReviewerName: "Rahul", Comments: "Poor", DateOfComment: "3/1/2011" }
        ]
        
        
        
    })
    db.moviesCollections.find({})
    
    db.moviesCollections.insert(
    {
        title: "Kabali",
        Description: "A Tamilian revolutionary is falsely imprisoned for 25 years while fighting against the cruelty of drugs in Malaysia.",
        Director: "Pa. Ranjith",
        Rating: 4,
        MusicBy: "Santosh Narayanan",
        Cast: ["Rajnikanth", "Radhika", "Dhansika"],
        SoundTrack: ["Maya Nadhi", "Ulagam"],
        GeneralInfo: { ReleaseDate: "19Oct 1995", Duration: "120min", Rating: 3, ProductionCompany: "Yash Raj Films" },
        Genre: "Horror",
        Reviews: [
            { ReviewerName: "Virat", Comments: "Excellent", DateOfComment: "1/1/2011" },
            { ReviewerName: "Viru", Comments: "Good", DateOfComment: "2/1/2011" }

        ]
    })
    
    db.moviesCollections.insert(
    {
        title: "Kick",
        Description: "Devi Lal Singh, a typical youth with an anomalous standard of living, tries to find pleasure in whatever he does. ",
        Director: "Sajid Nadialwala",
        Rating: 4,
        MusicBy: "Himmesh",
        Awards: ["Filmfare", "National Award", "Zee Cine Awards"],
        Cast: ["Salman", "Jaqline"],
        Genre: "Romantic",
        SoundTrack: ["Jumme ki Raat", "Hangover"],
        GeneralInfo: { ReleaseDate: "19Oct 2016", Duration: "120min", Rating: 2, ProductionCompany: "Yash Raj Films" },
        Reviews: [
            { ReviewerName: "Vishal", Comments: "Excellent", DateOfComment: "1/1/2011" },
            { ReviewerName: "Rajesh", Comments: "Good", DateOfComment: "2/1/2011" },
            { ReviewerName: "Ramu", Comments: "Poor", DateOfComment: "3/1/2011" }
        ]
    })
    
    db.moviesCollections.insert(
    {
        title: "Dangal",
        Description: "ndian wrestler Mahavir Singh trains his eldest two daughters to become champions in the sport, in the hope that they will attain the Olympic glory that he could not.",
        Director: "Nitesh Tiwari",
        Rating: 4,
        MusicBy: "Jatin-Lalit",
        Awards: ["Filmfare", "National Award"],
        Cast: ["Amir", "Sakshi"],
        Genre: "Horror",
        SoundTrack: ["Dhakkad", "Gillerihiyaan"],
        GeneralInfo: { ReleaseDate: "19Oct 2014", Duration: "120min", Rating: 5, ProductionCompany: "Amir Films" },
        Reviews: [
            { ReviewerName: "Satish", Comments: "Excellent", DateOfComment: "1/1/2011" },
            { ReviewerName: "Siddhu", Comments: "Good", DateOfComment: "2/1/2011" },
            { ReviewerName: "Samit", Comments: "Poor", DateOfComment: "3/1/2011" }
        ]
    })
    
    db.moviesCollections.find({})
    db.moviesCollections.find({"title":"Dangal"})
    db.moviesCollections.find({"Rating":{$gt:3}})
    
    db.moviesCollections.find({"Rating":{$lt:3}})
    
    db.moviesCollections.find({"Rating":{$ne:3}})
    