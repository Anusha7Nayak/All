function setEmpDetails(eid,name,desig,salary){
    this.eid=eid;
    this.name=name;
    this.desig=desig;
    this.salary=salary;
    displayEmpDetails =function(deptName)
    {
        var details=`
emp id: ${this.eid}  \n
emp name:${this.name} \n
dept name:${deptName} \n
designation: ${this.desig} \n
salary: ${this.salary}          `;
            // alert(details);
           var empObj= window.open("","empdetails ", "width=400px,height=400px;")
            var empDetails= `<html>
                                     <head>
                                        <title>Emp details</title>
                                     </head>
                                     <body style='font-family:segoe UI'>
                                         <table>
                                           <tr>
                                        <th> Eid </th>
                                        <td> ${this.eid} </td>
                                        </tr>
                                        <tr>
                                        <th> Eid </th>
                                        <td> ${this.name} </td>
                                        </tr>
                                        <tr>
                                        <th> Eid </th>
                                        <td> ${deptName} </td>
                                        </tr>
                                        <tr>
                                        <th> Eid </th>
                                        <td> ${this.desig} </td>
                                        </tr>
                                        <tr>
                                        <th> Eid </th>
                                        <td> ${this.salary} </td>
                                        </tr>
                                        </table>
                                        <body>
                                        </html>`;
                                        empObj.document.write(empDetails);
    }


}