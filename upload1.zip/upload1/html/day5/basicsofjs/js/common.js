
/* here showdate(_) is global variable Date() is builtin class in core objects in javascript */ 
var showDate=new Date();
/* this fn will be invoked on load*/
function showDateTime()
{
    document.getElementById("showDate").innerHTML="today's date and time is" + showDate ;
}