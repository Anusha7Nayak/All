/* for loop*/
function findFactorial_ForLoop(num)
{
    if(num.value==" ")
    
    alert("please enter only numbers")
    else
    {
        var n=parseInt(num.value);
        var fact=1;
        for(var i=1;i<=n;i++)
        fact *=i;
        alert("Factorial of " +n+ "is" +fact);
    }
}
/* for loop*/
function findFactorial_WhileLoop(num)
{
    if(num.value== "")
    alert("please enter only numbers")
    else
    {
        var n=parseInt(num.value);
        var fact=1;
      var i=1;
      //2) test cond
      while(i<=n){

     
        fact *=i;    //body of loop

        i++;          //incre decre
      }
        alert("Factorial of " +n+ "is" +fact);
    }
}
//funtion argument with variable number of argument
function function_Arguments(separator) {
    var result="";
    for(var i=1;i<arguments.length;i++)
    result+=arguments[i]+separator;
    document.write("<h2>"+result+"</h2>");
}
function Addition() {
    sum=0;
    for( var i=0;i<arguments.length;i++)
    sum+=parseInt(arguments[i]);
    return sum;
}
        document.write("<h3>addition(10,20,30) :" 
                +Addition(10,20,30 +"</h3>"));
                document.write("addition(10,20) :" 
                +Addition(10,20));
                document.write("addition(10,20,30,40) :" 
                +Addition(10,20,30,40));
