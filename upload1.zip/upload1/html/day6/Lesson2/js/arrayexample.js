//declaring and initializing an array in one line
var listofBoys=["pawan","kishore","sai"];
var listofGirls=["vipul","shalini","niharika"];
//empty declaration
//var number=[];
//var courses=new array[];
document.write("<h3>" +listofBoys+"</h3>");
document.write("<h3>" +listofGirls+"</h3>");

document.write("displaying  boys name using loops <br/>");
document.write("<h4>Boys count:" +listofBoys.length+"</h4>");
for(var i=0;i<listofBoys.length;i++)
document.write(listofBoys[i].bold()+"<br/>");

//adding at the end of list
listofBoys.push("mukund");
document.write("<h3> displaying after adding mukund <h3/>");
document.write("<h3>" +listofBoys + "<h3/>");
document.write("<h4> boys count:" +listofBoys.length+ "<h4/>");

document.write("<h4>girls count:" +listofGirls.length+"</h4>");
document.write("displaying  girlsname using loops <br/>");

for(var i=0;i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics()+"<br/>");
// at the beginning of list
listofGirls.unshift("Shreya");
document.write("<h3> displaying after adding shreya <h3/>");
document.write("<h3>" +listofGirls + "<h3/>");
document.write("<h4> girls count:" +listofGirls.length+ "<h4/>");

// used to remove element from end
//and return deleted element

document.write("<h3> deleted :" +listofGirls.pop() + "<h3/>");
document.write("<h3>" +listofGirls + "<h3/>");
document.write("<h4> girls count:" +listofGirls.length+ "<h4/>");

// adding element in between at specific location


document.write("<h3> sort girls in ascending order <br/>");
listofGirls.sort();
for(var i=0;i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics()+"<br/>");

document.write("<h3> sort girls in descending order <br/>");
listofGirls.reverse();
for(var i=0;i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics()+"<br/>");


var listofparticipants=listofGirls.concat(listofBoys);
document.write("<h3> final list in ascending order<h3/> <br/>")
listofparticipants.sort();
for(var i=0;i<listofparticipants.length;i++)
document.write(listofparticipants[i].bold().italics()+"<br/>");


var finallist=listofparticipants.join(', ');
document.write("<h3> final list :"+finallist +"<h3/>")
//slice return selected list of element
 //from an array with deleting it

document.write("<h3> first 3 :"+listofparticipants.slice(0,3) +"<h3/>")
// splice will return selcted list of elements
// even you can delete it
// even you can add between location
//1 parameter to start
//2 parameter to delete
// 3 parameter string array
listofparticipants.splice(2,2,"Anu","Akku");
document.write("<h1>" +listofparticipants+"<h1/>")

//mixed array
// var myList=["amit",20,"praveen"];
// document.write("<h3>" +my)

