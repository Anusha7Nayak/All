function checkEvenOrOdd(num){
var result;

    if(num.value==0)
    
        result="0 is neither even number";
else if(num.value %2==0)
     result= num.value+ "is a even number";
else
        result= num.value+ "is a odd number";
alert(result);
    
}
function displayDays(month, year){
    var days;
    
    switch(parseInt(month.value))
    {
      
    case 1:              //fallthrough
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
    {
        days = 31;
    }

    break;
    case 4:
    case 6:
    case 9:
    case 11:
    {
        days=30;
    }
    break;
    case 2:
    {
    if(year.value%4 == 0)
    {
    days=29;
    }
    else{
    days=28;
    }

    }
    break;
default: {
        day=-1;
    }
}
if(days ==-1)
alert("invalid month")
else
alert(month.value+ "has " +days+" days");
}
function checkMax(a,b)

{
    var res;
   res= a.value>b.value ? a.value + "is greater" : a.value<b.value ?  a.value +"is smaller": 
   "both are equal";
   alert(res);
  
   

  
}
