function calc(num1,num2,operation)
{
  var n1=parseInt(num1.value);
  var n2=parseInt(num2.value)
   var result;
   
   if(operation =="add")
   {
   result=(n1+n2);
   }
   
  else if (operation =='sub')
  {
 result=(n1-n2);
 }
 else if (operation =='mul')
  {
 result=(n1*n2);
 }
 else 
 {
  
 result=(n1/n2);
 }
alert(result);
}