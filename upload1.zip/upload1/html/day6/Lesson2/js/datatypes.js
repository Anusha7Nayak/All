var anyType;
//type of function return variable datatype
//undefined type
document.write("type:" +typeof(anyType)+" "+"value: "+anyType);
//string type
anyType="Narendra";
document.write("<br/>type:" +typeof(anyType)+" "+"value: "+anyType);
anyType=1000;
document.write("<br/>type:" +typeof(anyType)+" "+"value: "+anyType);
anyType=false;
document.write("<br/>type:" +typeof(anyType)+" "+"value: "+anyType);

anyType=null;
document.write("<br/>type:" +typeof(anyType)+" "+"value: "+anyType);

