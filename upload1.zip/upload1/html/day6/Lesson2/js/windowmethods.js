function calculateACircle(){

   calculate();
}

function calculate(){
    var radius=parseFloat(prompt("enter radius : ",5));
    var area= Math.PI*radius*radius;

    alert("area of circle is "+area);
var result=confirm("do ypu want to continue?");
if(result== true)
{
    calculate();
}
}
// set interval() and clear interval()
var intervalObj;
function setIntervalFunc() {
    intervalObj=setInterval(function() {
        alert('hello world');
    }, 2000);
}
function clearIntervalFunc() {
    clearInterval(intervalObj);
    alert('u have stopped interval..!');
}
// set timeout() clear timeout()
var timeOutObj;
function setTimeOutFunc() {
   timeOutObj=setTimeout(function() {
        alert('hello world');
    }, 3000);
}
function clearTimeOutFunc() {
    clearTimeout(timeOutObj);
    alert('u have stopped timeout..!');
}
function display()
{
    var message=this.id+""+this.name+""+this.desig+""+this.salary;
    alert(message);
    //creating object in javasciptwithout class
}
var emp1=new Object;
emp1.id=101;
emp1.name="anand";
emp1.desig="developer";
emp1.salary=25000;
//storing ref of one func in another func
emp1.displayEmp=display;
emp1.displayEmp();

var emp2=new Object;
emp2.id=102;
emp2.name="harish";
emp2.desig="developer";
emp2.salary=25000;
//storing ref of one func in another func
emp2.displayEmp=display;
emp2.displayEmp();

