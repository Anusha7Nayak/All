function usernameExist()
{
    if(localStorage.getItem("username")== null)
    {
        window.location="../pages/login.html";
       
    }
    document.getElementById("welcome").innerHTML="welcome to "   + localStorage.getItem("username");
    
}

function logout()
{
    var result=confirm("do you want to logout?");
    if(result)
    {

    
    //localStorage.length --.returns how many key stored inside localstorage object
    localStorage.removeItem("username");
    //clear all key in one go
    localStorage.clear()


       
    }
    if (localStorage.getItem("username")==null)
    {
        window.location="../pages/login.html";
}
}








function calculateSI(pa,noy,roi){
    if(pa.value=="" || noy.value=="" || roi.value=="")
    {
        alert('please fix all boxes !');
        return;
    }
    var si=parseFloat(pa.value) *parseInt(noy.value)*parseFloat(roi.value)/100;
    document.getElementById("result")
    .innerHTML="simple intrest is"+ si;

}
