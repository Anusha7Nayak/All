function login(frmLoginObj){
    if(frmLoginObj.checkValidity()){
        var username=frmLoginObj.txtUN.value;
        var  password=frmLoginObj.txtPD.value;
       alert(username);
       alert(password);
       if (username=="Narend" && password=="123456")
       {
           alert('login successfully');
           localStorage.setItem("username",username);
           //window.location="../pages/simpleint.html";
           window.open("../pages/simpleint.html");
          // alert(window.location);

       }
       else
       alert('login failed');
    }

}