class Rectangle {
    // constructor is initialized with parameter
    constructor(length,breadth) {
        this._length_=length;
        this._breadth_=breadth;
    }
    // setting length
    set length(length){
        this._length_=length;
    }
    //getting length
    get length(){
        return  this._length_;

    }
    // setting breadth
    set breadth(breadth){
        this._breadth_=breadth;
    }
    //getting breadth
    get breadthh(){
        return  this._breadth_;

    }
    // non static fn
    // calculateArea() {
    //     let area=this._length_*this._breadth_;
    //     return area;
    // }

      
//  static function we require classname to invoke it
    
   static display(){
       return "area of rectangle is";
   }

    // non static function
    calculateArea() {
        let area=this._length_*this._breadth_;
        return area;
    }
}


let length=parseFloat(prompt("Enter length"));
let breadth=parseFloat(prompt("Enter breadth"));
// initializing with properties i.e get and set method
let rectObj1=new Rectangle();
rectObj1.length=length;
 rectObj1.breadth=breadth;
 // 2 way using constructor for iitialization
 // creating rectangle class object
 // creating rectangle object 1 way using properties

 //invoking static fn using class name
let area1=rectObj1.calculateArea();
 console.log("using properties-" +Rectangle.display() + "" +area1);
let rectObj2=new Rectangle(length,breadth);
//ivoking  non static fn using object
//  let area2=rectObj2.calculateArea();
// console.log("using constructor -area of rectangle is" +area2);

