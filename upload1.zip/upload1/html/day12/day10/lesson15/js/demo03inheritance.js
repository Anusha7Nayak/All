// constructor in the order of base is derived
class BaseClass {
    constructor() {
        console.log("Base class is called");
    }
}
// inheriting from base class
class DerivedClass extends BaseClass {
    constructor() {
        //this is mandatary in derived class
        super();
        console.log("Derived class is called");
    }
}
let derivedObj=new DerivedClass();
//o/p Base class is called
// derived class is called



// super or parent class
class Employee
{
    constructor(id,name,salary) {
        this._id_=id;
        this._name_=name;
        this._salary_=salary;

    }
    showDetails() {
        let details=` Emp id: ${this._id_} 
                    Name: ${this._name_} 
                    salary: ${this._salary_}  
                    `;
                    return details;
    }

}
// child class or sub class
class Manager extends Employee{
constructor(id,name,salary,deptName){
    //super keyword is used to call 
    //base class constructor to initialize
    //derived class members

    super(id,name,salary);
    this._deptName_ =deptName;

}
//overrriding base class fn inside derived class is
//called as function overriding
showDetails(){
    return  "department name :" + this._deptName_ + " " + super.showDetails();
}
}
var mgrObj=new Manager(101,"dora",25000,"IT");
console.log(mgrObj.showDetails());
// super keyword points to immediate base class
// super keyword is derived class,it is used to invoke base class constructor
//super keyword is also used to invoke base class members an fn
//it avoids ambguity between base class members and derived class members

class SuperClass{
    constructor(id) {
        this._cid_=20;
     }
     display() {
         return this._cid_;
     }
}
class SubClass extends SuperClass{
    constructor() {
        super();
        this._id_=10;
    }
    display() {
        console.log("Instance variable: "+this._id_);
        console.log("Instance variable: "+super.display());


    }
}
let subObj=new SubClass();
subObj.display();   


// task

