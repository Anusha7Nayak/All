class mobile{
    constructor(mobileId,mobileName,mobileDetails)
    {
       this._mobileId_=mobileId;
       this._mobileName_=mobileName;
       this._mobileDetails_=mobileDetails;

    }
    printMobileDetails(){
        var mobDetails=
            `mobileId: ${  this._mobileId_}
            mobileName: ${  this._mobileName_}   
             mobiledetails: ${  this._mobileDetails_}  
              `;
              return mobDetails;

    }
   

}
class basicPhone extends mobile{
    constructor(mobileId,mobileName,mobileDetails,mobileType) {
        super(mobileId,mobileName,mobileDetails);
         this._mobileType_=mobileType;

    }
    printMobileDetails(){
        let mobDetails=super.printMobileDetails()+
        "mobile type :" +this._mobileType_;
        return mobDetails;
    }
}


class smartPhone extends mobile{
    constructor(mobileId,mobileName,mobileDetails,mobileType) {
        super(mobileId,mobileName,mobileDetails);
         this._mobileType_=mobileType;

    }
    printMobileDetails(){
        let mobDetails=super.printMobileDetails()+
        "mobile type :" +this._mobileType_;
        return mobDetails;
    }
}
var basicPhoneObj= new basicPhone(1,"nokia","personal","keypad");
// console.log( basicPhoneObj. printMobileDetails());

var smartPhoneObj= new smartPhone(2,"vivo","personal","touch");
// console.log( smartPhoneObj. printMobileDetails());



//crud operations
 // add
let allmobile=[];
 allmobile.push(basicPhoneObj);
 allmobile.push(smartPhoneObj);

 for( var mobil in allmobile){
    console.log(allmobile[mobil].printMobileDetails());
}
// // delete
console.log(typeof(allmobile[0]._mobileId_));

let mobileId=parseInt(prompt("enter mobile id"));
console.log(typeof(mobileId));
for(let mobile in allmobile){
      if(allmobile[mobile]._mobileId_===mobileId) {
         allmobile.splice(mobile,1);
      }
     }
    console.log("after removing product name");
 //reading from array
 for( let mobile in allmobile){
     console.log(allmobile[mobile].printMobileDetails());
 }


// update
// let mobileId=parseInt(prompt("enter mobile id"));
//  for(var mobil in allmobile){
//      if(allmobile[mobil]._mobileId_===mobileId) {
//           allmobile[mobil]._mobileName_ ="samsung";


//       }
//  else {
//     console.log("mobile ID doesnot exist");
//  }
//  }
//  console.log("after changing mobilename");
//  //reading from array
//  for( var mobil in allmobile){
//   console.log(allmobile[mobil].printMobileDetails());
//  }

