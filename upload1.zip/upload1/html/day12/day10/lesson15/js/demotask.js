class shape{
    constructor(radius,length,breadth){
        this._radius_=radius;
        this._length_=length;
        this._breadth_=breadth;

    }
    calculateArea(){
     
        
       console.log("this is shape class" );
     
        
  
    }
}
// derived class
class circle extends shape{
     constructor( radius){
         super(radius);
        
  
     }
     calculateArea(){
    let area=3.142*this._radius_ *this._radius_;
     return area;
       
     }
}

class Rectangle extends shape{
    constructor( length,breadth){
        super();
        this._length_=length;
        this._breadth_=breadth;

       
 
    }
    calculateArea(){
   let area= this._length_* this._breadth_;
    return area;
      
    }
}



let circleObj=new circle( radius=5);
console.log("area of circle is:"+ circleObj.calculateArea()) ;




let rectObj=new Rectangle( length=5,breadth=10);
console.log("area of rectangle is:"+ rectObj.calculateArea()) ;
  


