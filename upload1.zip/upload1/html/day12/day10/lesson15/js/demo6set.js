class product {
    constructor(productId,productName,productPrice,productDescription){
               this._productId_=productId;
               this._productName_=productName;
               this._productPrice_=productPrice;
               this._productDescription_=productDescription;

    }
    // function
    printAllProduct() {
        var productDetails=
        `product Id: ${this._productId_}
        product Name: ${this._productName_}
        product Price: ${this._productPrice_}
        product Description: ${this._productDescription_}
        `;
return productDetails;
    }
}// end of product class

class product1 extends product{
    constructor(productId,productName,
        productPrice,productDescription,productType){
            super(productId,productName,
                productPrice,productDescription);
                this._productType_=productType;
        }
        //function
        printAllProduct() {
            let allDetails=super.printAllProduct()+
            "product type :" +this._productType_;
            return allDetails;
        }
}// end of product1 class


class product2 extends product{
    constructor(productId,productName,
        productPrice,productDescription,productCategory){
            super(productId,productName,
                productPrice,productDescription);
                this._productCategory_=productCategory;
        }
        //function
        printAllProduct() {
            let allDetails=super.printAllProduct()+
            "product category :" +  this._productCategory_;
            return allDetails;
        }
}// end of product 2
var product1Obj=new product1("p1","Laptop",25000,
"personal","education");
// console.log(product1Obj.printAllProduct());

var product2Obj=new product2("p2","AC",5000,
"personal","home appliance");
// console.log(product2Obj.printAllProduct());

var product3Obj=new product2("p3","Fan",15000,
"personal","home appliance");

var product4Obj=new product1("p4","AC",85000,
"personal","home appliance");

// creating set object using set constructor
let allProducts= new Set();
//crud operation
//add array
allProducts.add(product1Obj);
allProducts.add(product2Obj);
allProducts.add(product3Obj);
allProducts.add(product4Obj);


//reading array
for( let productt of allProducts){
    console.log(productt.printAllProduct());
}
//sort

console.log("after sorting in ascending order");
let sortedSet=Array.from(allProducts)
.sort((a,b) => a._productPrice_ -b._productPrice_);


for(let  productt of sortedSet) {
    console.log(productt.printAllProduct());
}


//updating  from an set
//  let productId=prompt("enter product id");
//  // 1 way using find method
//  let updatedProduct=
//  Array.from(allProducts).find(p =>p._productId_===productId);

//  updatedProduct._productName_="hp Laptop";

// //  // 2 method using for loop
// //  for(var productt of allProducts){
// //      if(productt._productId_===productId) {
// //           productt._productName_ = "HP Laptop";


// //      }
// //     }

//     console.log("after changing product name");

//  for( var productt of allProducts){
//      console.log(productt.printAllProduct());
//  }



// // // deleting an set
 let productId=prompt("enter product id");
 let deletedProduct=
 Array.from(allProducts).find(p =>p._productId_===productId);
 allProducts.delete(deletedProduct);


//  for(let product of allProducts){
//      if(productt._productId_===productId) {
//         allProducts.delete(product);
//      }
//     }
    console.log("after removing product name");
// // //reading from array
 for( var productt of allProducts){
   console.log(productt.printAllProduct());
}
