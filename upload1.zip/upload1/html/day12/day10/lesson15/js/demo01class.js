// create class rectangle
class Rectangle {
    constructor() {
        console.log("constructor of rectangle class is called..!");

    }
    calculateArea(l,b) {
        let area=l*b;
        return area;
    }
}
let rectObj=new Rectangle();
let length=parseFloat(prompt("Enter length"));
let breadth=parseFloat(prompt("Enter breadth"));
let area=rectObj.calculateArea(length,breadth);
console.log(area);


 // create class rectangle
class square {
    constructor() {
        console.log("constructor of square class is called..!");

    }
    calculateArea(a,c) {
        let are=a*c;
        return are;
    }
}
let sqObj=new square();
let lengt=parseFloat(prompt("Enter length"));
let breadt=parseFloat(prompt("Enter breadth"));
let are=sqObj.calculateArea(lengt,breadt);
console.log(are);


 