class Inventory {
    constructor(){
               
    }
    // function
    getUserIn() {
  
      

    }
    getUserOut() {
        
    }
}// end of inventory class

class User extends Inventory{
    constructor(uId, uName, uAge, uCity){
            super()
             this._uId_= uId;
             this._uName_= uName;
             this._uAge_= uAge;
             this._uCity_= uCity;




        }
        //function
      printAllUsers() {
         
           var allDetails=
          `
           user Id: ${ this._uId_}
           user Name: ${this._uName_}
           user age: ${this._uAge_}
           user city: ${this._uCity_}
            `;
         return allDetails;
        
       
        }
        getUserIn() {
            console.log("login successfully");
              
        
            }
            getUserOut() {
                console.log("logoout successfully");
            }
      

        
    }
 
        var user1Obj=new User(1001,"Rahul", 19, "Mumbai");
        // console.log(user1Obj.printAllUsers());

        
        var user2Obj=new User(1002,"Ram", 66, "Pune");
        // console.log(user2Obj.printAllUsers());
        

        
        var user3Obj=new User(1003,"Penny", 32, "Delhi");
        // console.log(user3Obj.printAllUsers());
        
        
        var user4Obj=new User(1004,"Sheldon", 30, "Delhi");
        // console.log(user4Obj.printAllUsers());


        //adding by  map
        
let allUsers= new Set();
allUsers.add(user1Obj);
allUsers.add(user2Obj);
allUsers.add(user3Obj);
allUsers.add(user4Obj);


//reading array
for( let users of allUsers){
    console.log(users.printAllUsers());
}




// sort
console.log("after sorting in ascending order");
let sortedSet=Array.from(allUsers)
.sort((a,b) => a._uAge_ -b._uAge_);


for(let users of sortedSet) {
    console.log(users.printAllUsers());
}
    // deleting

let userId=parseInt(prompt("enter user id"));
 let deletedUser=
 Array.from(allUsers).find(p =>p._uId_===userId);
 if(deletedUser==undefined)
 {
     console.log("no exist");
 }
 else{


 allUsers.delete(deletedUser);

 console.log("after removing product name");
 }
 //  //reading from array
  for( let user of allUsers){
    console.log(user.printAllUsers());
 }

    user1Obj.getUserIn();    
  user2Obj.getUserOut();   




      

