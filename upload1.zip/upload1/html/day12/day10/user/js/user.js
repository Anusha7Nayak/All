class Inventory {
    constructor(){
               
    }
    // function
    getUserIn() {
  
      

    }
    getUserOut() {
        
    }
}// end of inventory class

class User extends Inventory{
    constructor(uId, uName, uAge, uCity){
            super()
             this._uId_= uId;
             this._uName_= uName;
             this._uAge_= uAge;
             this._uCity_= uCity;




        }
        //function
      printAllUsers() {
         
           var allDetails=
          `
           user Id: ${ this._uId_}
           user Name: ${this._uName_}
           user age: ${this._uAge_}
           user city: ${this._uCity_}
            `;
         return allDetails;
        
       
        }
        getUserIn() {
            console.log("login successfully");
              
        
            }
            getUserOut() {
                console.log("logoout successfully");
            }
      

        
    }
 
        var user1Obj=new User(1001,"Rahul", 19, "Mumbai");
        // console.log(user1Obj.printAllUsers());

        
        var user2Obj=new User(1002,"Ram", 66, "Pune");
        // console.log(user2Obj.printAllUsers());
        

        
        var user3Obj=new User(1003,"Penny", 32, "Delhi");
        // console.log(user3Obj.printAllUsers());
        
        
        var user4Obj=new User(1004,"Sheldon", 30, "Delhi");
        // console.log(user4Obj.printAllUsers());


        //adding by  map
        
let allUsers= new Map();
allUsers.set(1,user1Obj);
allUsers.set(2,user2Obj);
allUsers.set(3,user3Obj);
allUsers.set(4,user4Obj);


//reading array
for( var [k,v] of allUsers){
    console.log(allUsers.get(k).printAllUsers());
}



// sorting array
console.log("after sorting in ascending order");


 let sortedMap=Array.from(allUsers)
 .sort((a,b) => a[1]._uAge_ - b[1]._uAge_);


 for( var [k,v] of sortedMap){
    console.log(allUsers.get(k).printAllUsers());
}
    
let userId = parseInt(prompt("enter user id"));
  let deletedUser=
  Array.from(allUsers).find(p =>p[1]._uId_===userId);
 

   if( deletedUser==undefined)
   {
       console.log("not exist");
     

       
   }
   else {
       allUsers.delete(deletedUser[0]);
       console.log("after deleting "); 
   }


 // reading array
 
  for( var [k,v] of allUsers){
    console.log(allUsers.get(k).printAllUsers());
}
   user1Obj.getUserIn();    
   user2Obj.getUserOut();   




      

