// Declaring array using array indexing symbol[]
var numbers: number[]= [10,20,30,40,50];

console.log("displaying numbers");
for(let n in numbers) {
    console.log(n);
}

//Declaring array using array() constructor

var  newNumbers=new Array(5);
console.log("Displaying New Numbers");
for(let i=0;i<newNumbers.length;i++) {
    newNumbers[i]=numbers[i] +10;
}
console.log(...newNumbers);

// array constructor accepts comma seperated values
var studentList:string[]=
   new Array("anu","vijaya" ,"akku","annappa")
   console.log(...studentList);

   //array destructing
   var arrObj: number[]=[10,10]
   var[x,y]= arrObj;
   console.log(x);
   console.log(y);

   // shift()-removes the first element from an array
   //and returns that element
   //Unshift() -adds one or more element from an array and
   // returns that element..

   //push()-add one or more elements to the end of an array and returns new element
   //to array
   //splice()- adds  or removes eleemnt from array
   //pop()- removes last element from array
   //slice()-extract a section of an array and returns a new array.

   //2d array
   var twoDArray: number[][]= [[1,2,3],[45,25,25]]
   console.log(...twoDArray);

   //console.log(twoDArray[0][0])
    //console.log(twoDArray[0][1])
     //console.log(twoDArray[0][2])
      //console.log(twoDArray[1][0])
       //console.log(twoDArray[1][1])
        //console.log(twoDArray[1][2])
