interface IPerson{
    firstName:string,
    lastName:string,
    showFullName:() =>string;
}
var customerObj: IPerson={
    firstName: "Anusha",
    lastName: "Nayak",
    showFullName:  (): string =>{
        return customerObj.firstName
        + "" +customerObj.lastName} 
}
console.log("full name of customer: " +customerObj.showFullName());

// reusing functionality of interface
var studentObj: IPerson ={
    firstName: "vijaya",
    lastName: "laxmi",
    showFullName: (): string => {
        return studentObj.firstName+ "" + studentObj.lastName
     } 

}
console.log("full name of student: " +studentObj.showFullName());

//interface to interface inheritance
interface IMusician extends IPerson {
    age:number,
    instrument:string
}
//var drummer:IMusician;
//or type assertion

var drummer=<IMusician>{};
drummer.firstName="akshatha";
drummer.lastName="nayak";
drummer.age=25;
drummer.instrument="drums";

let details = `Drummer Name ${drummer.firstName} ${drummer.lastName}
              Drummer age: ${drummer.age}
            Drummer Instrument ${drummer.instrument}`
            console.log(details);
            //multiple inheritance

            interface IHDFCBank{
                hoursOfWork:number
            }
            interface ICitiBank {
                projectName:string
            }
            interface 
            //java syntax of implementing interfaces
            class Employee implements IHDFCBank, ICitiBank {
                name:string;
                salary:number;
                //overriding members of IHDFCBank and ICitiBank
                projectName:string;
                hoursOfWork:number;
            
                constructor(name:string,salary:number,projectName:string,
                    hoursOfWork:number){
                    this.name=name;
                    this.salary=salary;
                    this.projectName=projectName;
                    this.hoursOfWork=hoursOfWork;


                }
                printDetails():string {
                    let details=
                    `project name ${this.projectName}
                        employee name ${this.name}
                        working hours ${this.hoursOfWork}
                        salary ${this.salary}
                        `;
                        return details;
                }

            }// end of class

            let empObj=new Employee("anu",25200,"insurance automation",100);
            console.log(empObj.printDetails());

            // this line implements printdetails of IOperations
            let empObj1:IOperationsnew Employee("anu",25200,"insurance automation",100);
            console.log(empObj.printDetails());