//understanding access specifiers
//public,private,protected
class MyClass {
    //by default protected
    //private companyName:string="IGATE"
    //protected  companyName:string="IGATE"
   companyName:string="IGATE";

}
//instance of keyword
var myClassObj = new MyClass ();
console.log("instance of keyword"  +(myClassObj instanceof MyClass));

//Accessible public member outside class
console.log("default name"  +myClassObj.companyName);

//changing name
myClassObj.companyName="capGemini";
//aaccessing public member outside class
console.log("after name changes" +myClassObj.companyName);



//using constructor to initialize class mmbers
class Product {
    //member variables
    firstNumber:number;
    secondNumber:number;
    //constructor overloading
//chieving with default arguments
    constructor( firstNumber:number=20, secondNumber:number=10) {
       this.firstNumber=firstNumber;
        this.secondNumber= secondNumber;
    }
    calculateProduct(): number {
        let result= this.firstNumber*   this.secondNumber;
        return result;
    }

}// end of class
var myProduct1=new Product(100,20)
console.log("product of 2 numbers" +myProduct1.calculateProduct());


var myProduct2=new Product(10,20)
console.log("product of 2 numbers" +myProduct2.calculateProduct());



//types of inheritance
//1.single level-only one parent class and one child class
//2.multi level-child class is derived from another parent class
//3.multiple-child class is derived frommore than one parentclass
// it is not supported by typescript directly use interfaces
//4.hybrid inheritance-not supported but combination of hierrachical and multiple inheritance
//5.Hierachical-like a family tree

//using inheritance between class

//using inheritance between classes and methopd overlriding
//use of super keyword and using extends keyword


class Geometry{
   protected side:number;
   protected  base:number;
   protected  height:number;

    //base class function
    calculate(): void {}



}
class Square extends Geometry {
    static counter:number=0;
    constructor(side:number){
        super();
        this.side=side;
        Square.counter++;
    }
    //overriding calculate() function of geometry class
    calculate():void{
        let area=this.side*this.side;
        console.log("area of square "+ area);
    }
    static getCount(): number {
        return Square.counter;
    }
}
let squareObj1=new Square(5);
squareObj1.calculate();

let squareObj2=new Square(3);
squareObj2.calculate();

let squareObj3=new Square(3);
squareObj3.calculate();
console.log("square objects count" +Square.counter);
//use of super keyword