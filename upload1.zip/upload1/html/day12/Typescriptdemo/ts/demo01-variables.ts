//basetype
// Decraling variables
// Dynamic types
var someType:any=10;
// class name for string
console.log("someType here: typeof:" +typeof(someType));
someType="hello world";

// class name for boolean
console.log("someType here: typeof:" +typeof(someType));
someType=true;

console.log("someType here: typeof:" +typeof(someType));
someType=null;

console.log("someType here: typeof:" +typeof(someType));
someType=undefined;


//static type:once you declare any variable with some type
//through the scope

var eid:number=101;
var ename:string="Anusha";
var salary:number=2500.00;
var empstatus:boolean=false;
// Displaying variables
console.log("Employee id is" +eid);
console.log("Employee name is"+ename);
console.log("Employee id is" +salary);


if(empstatus)
console.log("Employee is selected");
else
console.log("Employee is rejected");