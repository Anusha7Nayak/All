abstract class Person {
abstract show (): void;
//child class must overrid all abstract function of parent class


}
class Customer extends Person {
show():void{
    console.log("overridden method of person class")
}
}
//let personObj=new Person();
//dynamic polymorphism
let customerObj: Person = new Customer();
customerObj.show();