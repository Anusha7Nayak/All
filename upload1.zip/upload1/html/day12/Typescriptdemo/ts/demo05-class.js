var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//understanding access specifiers
//public,private,protected
var MyClass = /** @class */ (function () {
    function MyClass() {
        //by default protected
        //private companyName:string="IGATE"
        //protected  companyName:string="IGATE"
        this.companyName = "IGATE";
    }
    return MyClass;
}());
//instance of keyword
var myClassObj = new MyClass();
console.log("instance of keyword" + (myClassObj instanceof MyClass));
//Accessible public member outside class
console.log("default name" + myClassObj.companyName);
//changing name
myClassObj.companyName = "capGemini";
//aaccessing public member outside class
console.log("after name changes" + myClassObj.companyName);
//using constructor to initialize class mmbers
var Product = /** @class */ (function () {
    //constructor overloading
    //chieving with default arguments
    function Product(firstNumber, secondNumber) {
        if (firstNumber === void 0) { firstNumber = 20; }
        if (secondNumber === void 0) { secondNumber = 10; }
        this.firstNumber = firstNumber;
        this.secondNumber = secondNumber;
    }
    Product.prototype.calculateProduct = function () {
        var result = this.firstNumber * this.secondNumber;
        return result;
    };
    return Product;
}()); // end of class
var myProduct1 = new Product(100, 20);
console.log("product of 2 numbers" + myProduct1.calculateProduct());
var myProduct2 = new Product(10, 20);
console.log("product of 2 numbers" + myProduct2.calculateProduct());
//types of inheritance
//1.single level-only one parent class and one child class
//2.multi level-child class is derived from another parent class
//3.multiple-child class is derived frommore than one parentclass
// it is not supported by typescript directly use interfaces
//4.hybrid inheritance-not supported but combination of hierrachical and multiple inheritance
//5.Hierachical-like a family tree
//using inheritance between class
//using inheritance between classes and methopd overlriding
//use of super keyword and using extends keyword
var Geometry = /** @class */ (function () {
    function Geometry() {
    }
    //base class function
    Geometry.prototype.calculate = function () { };
    return Geometry;
}());
var Square = /** @class */ (function (_super) {
    __extends(Square, _super);
    function Square(side) {
        var _this = _super.call(this) || this;
        _this.side = side;
        Square.counter++;
        return _this;
    }
    //overriding calculate() function of geometry class
    Square.prototype.calculate = function () {
        var area = this.side * this.side;
        console.log("area of square " + area);
    };
    Square.getCount = function () {
        return Square.counter;
    };
    Square.counter = 0;
    return Square;
}(Geometry));
var squareObj1 = new Square(5);
squareObj1.calculate();
var squareObj2 = new Square(3);
squareObj2.calculate();
var squareObj3 = new Square(3);
squareObj3.calculate();
console.log("square objects count" + Square.counter);
//use of super keyword
