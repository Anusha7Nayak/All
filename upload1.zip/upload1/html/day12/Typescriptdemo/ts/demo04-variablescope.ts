var global_Num : number=100;

class VariableScope {
    //by default class members-meaning  variable function 
    //instance variable which require object to access
    //life time of this variable is depends on objects
    //it is bound to object
    instance_Num:number=10;
    
  //note:static members are non static memnber of class
  // are by default initialized to undefined
  //unlike java where intilized to default values like 0 for int etc 


// class variable or static variable which require classname
//life time of this variable depends on class
//it is bound to class


static static_Num:number=100;
//non static function can access non static and static members
   displayNum(local_Num:number=5) {
       console.log("global_num: " +global_Num);
       console.log("instance_num: " +this.instance_Num);
       console.log("local_num: " +local_Num);
       console.log("static_num: " +VariableScope.static_Num);

   }
   //static functiom can access ststic member
   //non static members are not allowed
   //But you can declare non static member inside static function
   static displayStaticNumber(): void {
    console.log(VariableScope.static_Num);
    // console.log("instance_num: " +this.instance_Num);
    //non static member declaration
    //let num:number=20;
   }
}
var obj=new VariableScope();
console.log("\n\tglobal_Num:" +global_Num);
console.log("variable scope.static_num: " +VariableScope.static_Num);

//calling by default parameter
obj.displayNum();
//calling with parameter
obj.displayNum(20);


