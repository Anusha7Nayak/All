function addition(firstNumber, secondNumber) {
    return (firstNumber + secondNumber);
}
console.log(addition(20, 30));
console.log(addition(20.33333, 30.63));
console.log(addition(90.33333, 30.63));
console.log(addition("vijay", "laxmi"));
//  generic class
var Calculator = /** @class */ (function () {
    function Calculator() {
    }
    return Calculator;
}());
var result = new Calculator();
result.add = function (x, y) { return x + y; };
console.log(result.add(50, 60));
//fn template
var Calculator = /** @class */ (function () {
    function Calculator() {
    }
    Calculator.prototype.add = function (one, two) {
        return one + two;
    };
    return Calculator;
}());
var obj1 = new Calculator();
console.log(obj1.add(10, 20));
var obj2 = new Calculator();
console.log(obj2.add("100", "20"));
