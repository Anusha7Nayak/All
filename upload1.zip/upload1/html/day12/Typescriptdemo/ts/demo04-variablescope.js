var global_Num = 100;
var VariableScope = /** @class */ (function () {
    function VariableScope() {
        //by default class members-meaning  variable function 
        //instance variable which require object to access
        //life time of this variable is depends on objects
        //it is bound to object
        this.instance_Num = 10;
    }
    VariableScope.prototype.displayNum = function (local_Num) {
        if (local_Num === void 0) { local_Num = 5; }
        console.log("global_num: " + global_Num);
        console.log("instance_num: " + this.instance_Num);
        console.log("local_num: " + local_Num);
        console.log("static_num: " + VariableScope.static_Num);
    };
    //static functiom can access ststic member
    //non static members are not allowed
    //But you can declare non static member inside static function
    VariableScope.displayStaticNumber = function () {
        console.log(VariableScope.static_Num);
        // console.log("instance_num: " +this.instance_Num);
        //non static member declaration
        //let num:number=20;
    };
    // class variable or static variable which require classname
    //life time of this variable depends on class
    //it is bound to class
    //non static function can access non static and static members
    VariableScope.static_Num = 100;
    return VariableScope;
}());
var obj = new VariableScope();
console.log("\n\tglobal_Num:" + global_Num);
console.log("variable scope.static_num: " + VariableScope.static_Num);
//calling by default parameter
obj.displayNum();
//calling with parameter
obj.displayNum(20);
