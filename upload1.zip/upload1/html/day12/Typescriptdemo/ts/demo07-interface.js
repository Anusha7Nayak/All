var customerObj = {
    firstName: "Anusha",
    lastName: "Nayak",
    showFullName: function () {
        return customerObj.firstName
            + "" + customerObj.lastName;
    }
};
console.log("full name of customer: " + customerObj.showFullName());
// reusing functionality of interface
var studentObj = {
    firstName: "vijaya",
    lastName: "laxmi",
    showFullName: function () {
        return studentObj.firstName + "" + studentObj.lastName;
    }
};
console.log("full name of student: " + studentObj.showFullName());
//var drummer:IMusician;
//or type assertion
var drummer = {};
drummer.firstName = "akshatha";
drummer.lastName = "nayak";
drummer.age = 25;
drummer.instrument = "drums";
var details = "Drummer Name " + drummer.firstName + " " + drummer.lastName + "\n              Drummer age: " + drummer.age + "\n            Drummer Instrument " + drummer.instrument;
console.log(details);
//java syntax of implementing interfaces
var Employee = /** @class */ (function () {
    function Employee(name, salary, projectName, hoursOfWork) {
        this.name = name;
        this.salary = salary;
        this.projectName = projectName;
        this.hoursOfWork = hoursOfWork;
    }
    Employee.prototype.printDetails = function () {
        var details = " project name " + this.projectName + "\n                        employee name " + this.name + "\n                        working hours " + this.hoursOfWork + "\n                        salary " + this.salary + "\n                        ";
        return details;
    };
    return Employee;
}()); // end of class
var empObj = new Employee("anu", 25200, "insurance automation", 100);
console.log(empObj.printDetails());
