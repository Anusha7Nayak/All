var eid = 101;
var ename = "Anusha";
var salary = 2500.00;
var empstatus = true;
console.log("Employee id is" + eid);
console.log("Employee name is" + ename);
console.log("Employee id is" + salary);
if (empstatus)
    console.log("Employee is selected");
else
    console.log("Employee is rejected");
