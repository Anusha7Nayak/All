// Arrow operator with paramter
var circle = function (r) { return 3.142 * r * r; };
// Arrow operator without parameter
var areaOfCircle = function () { return console.log(circle(5)); };
areaOfCircle();
//simple interet
var SI = function (p, t, r) { return p * t * r / 100; };
var simpleInterest = function () {
    return console.log(SI(1000, 2, 2));
};
simpleInterest();
function calculateSi(pa, noy, roi) {
    if (roi === void 0) { roi = 2; }
    var si = pa * noy * roi / 100;
    return si;
    //console.log("SI is" +si);
}
console.log("SI is" + calculateSi(1000, 2, 2));
//named paramter
//console.log("Si is" +calculateSi(noy=2,pa=1000,roi=2));
// defaultparamter-will be initilized to some default value
console.log("si is" + calculateSi(1000));
//optional paramter will make use of ? paramter name to
//inform compiler that paramter value is optional
console.log("si is" + calculateSi(1000, 2));
function calculateArea(a, b) {
    var area;
    if (b === undefined)
        area = 3.142 * a * a;
    else
        area = a * b;
    return area;
}
// circle
console.log("area of circle is" + calculateArea(10));
//rectangle
console.log("area of rectangle is" + calculateArea(10, 20));
//anonymous function with paramter
var res = function (a, b) {
    return a * b;
};
console.log(res(12, 2));
// the function constructor
var myFunction = new Function("a", "b", "return a*b");
var product = myFunction(4, 3);
console.log(product);
//parameter type inference
//based on initilized value type will be decided is known as
//
var showType = function (x) {
    if (typeof x == "number") {
        console.log(x + "is numeric");
    }
    else if (typeof x == "string") {
        console.log(x + "is a string");
    }
};
showType(12);
showType("hello");
// rest parameter
function addNumbers() {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var i;
    var sum = 0;
    for (i = 0; i < nums.length; i++) {
        sum = sum + nums[i];
    }
    //OR using For ..in loop
    //for(i in num)
    //sum+=i;
    console.log("sum of the numbers", sum);
}
addNumbers(1, 2, 3);
addNumbers(10, 20, 30, 10, 10);
