// union
// two or more data types are combined using pipe symbol(|)
//to denote a union type.i other words a union type is written
//as a sequence of types seperated by vertical bars
//eg
var val;
val = 25;
console.log("numeric value of val  " + val);
val = "hello world";
console.log("string  value of val  " + val);
//union type and function parameter
function disp(name) {
    if (typeof name == "string") {
        console.log(name);
    }
    else {
        var i;
        for (i = 0; i < name.length; i++) {
            console.log(name[i]);
        }
    }
}
disp("Nihal");
console.log("printing names array");
disp(["sandesh", "jeevesh", "jatin", "abhinav"]);
//union type and array
var arrType;
var i;
arrType = [10, 20, 30, 40];
console.log("numeric array");
for (i = 0; i < arrType.length; i++) {
    console.log(arrType[i]);
}
arrType = ["Mumbai", "Pune", "Delhi"];
console.log("string array");
for (i = 0; i < arrType.length; i++) {
    console.log(arrType[i]);
}
