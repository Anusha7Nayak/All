// tuples
// at times there might be a need to store a collection of values 
//of varied types.array will not  served this puropse
var studentTupleObj = [101, "Neha"];
console.log(studentTupleObj[0]);
console.log(studentTupleObj[1]);
var customerTuple = [101, "Shray", "pune", "laptop"];
//return tuple size
console.log("Items before push" + customerTuple.length);
// append value to the tuple
customerTuple.push(25555);
console.log("customer tuple after push" + customerTuple.length);
console.log("Icustomer tuple before push" + customerTuple.length);
// removes and return last item
console.log(customerTuple.pop() + "popped from tupple");
console.log("customer tuple after pop" + customerTuple.length);
// destructing a tuple
var empObj = [101, "Amith"];
var id = empObj[0], ename = empObj[1];
console.log(id);
console.log(ename);
