
//import {company} from "./productmodule/product";

//import {product} from "./productmodule/product";
//or
// import * as products from "./productmodule/product";

import {Company, Product} from "./productmodule/product";
// declare product
let prod:Product={productId: 1001, productName:"iphone"}

let productArray:Product[] =
[{ productId:1002,productName:"LG"},
{ productId:1003,productName:"coolpad"},
{ productId:1004,productName:"Mi"}
];

console.log(prod.productId + " " +prod.productName +"\n");

for (let pro of productArray) {
    console.log(pro.productId + " " +pro.productName + "\n");

}
console.log(Company);
//incase of * syntax
//console.log(products.company);