import { IShape}  from "./shapemodule/IShape";
import { Circle}  from "./shapemodule/circle";
import { Traingle}  from "./shapemodule/traingle";

function drawAllShapes(shapeToDraw: IShape) {
    shapeToDraw.draw();

}
drawAllShapes(new Circle());
drawAllShapes(new Traingle());


console.log( "area of circle is" +new Circle.area(2));
console.log( "area of traingle is" +areaofTraingle(20,30));
