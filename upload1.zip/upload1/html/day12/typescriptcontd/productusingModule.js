"use strict";
//import {company} from "./productmodule/product";
exports.__esModule = true;
//import {product} from "./productmodule/product";
//or
// import * as products from "./productmodule/product";
var product_1 = require("./productmodule/product");
// declare product
var prod = { productId: 1001, productName: "iphone" };
var productArray = [{ productId: 1002, productName: "LG" },
    { productId: 1003, productName: "coolpad" },
    { productId: 1004, productName: "Mi" }
];
console.log(prod.productId + " " + prod.productName + "\n");
for (var _i = 0, productArray_1 = productArray; _i < productArray_1.length; _i++) {
    var pro = productArray_1[_i];
    console.log(pro.productId + " " + pro.productName + "\n");
}
console.log(product_1.Company);
//incase of * syntax
//console.log(products.company);
