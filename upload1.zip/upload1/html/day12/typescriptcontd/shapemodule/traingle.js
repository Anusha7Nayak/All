"use strict";
exports.__esModule = true;
var Traingle = /** @class */ (function () {
    function Traingle() {
    }
    Traingle.prototype.draw = function () {
        console.log("traingle is drawn(external module)");
    };
    return Traingle;
}());
exports.Traingle = Traingle;
