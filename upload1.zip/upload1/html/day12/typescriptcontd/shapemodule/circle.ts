import { IShape } from "./IShape";
export class Circle implements IShape {
    public draw() {
        console.log("circle is drawn(external module)");
    }
    public area(radius:number):number {
        let areaOfCircle=3.142*radius*radius;
    return areaOfCircle;
    }
}