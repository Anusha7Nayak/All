import { IShape } from "./IShape";
export class Traingle implements IShape {
    public draw() {
        console.log("traingle is drawn(external module)");
    }
    public area(base:number ,height:number):number {
        let areaOfTraingle=3.142*base*height;
    return areaOfTraingle;
}
}