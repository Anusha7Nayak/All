export interface IShape {
    draw();
    // calculate area of shapes
    area(base:number,height?: number):number;
}

