"use strict";
exports.__esModule = true;
var circle_1 = require("./shapemodule/circle");
var traingle_1 = require("./shapemodule/traingle");
function drawAllShapes(shapeToDraw) {
    shapeToDraw.draw();
}
drawAllShapes(new circle_1.Circle());
drawAllShapes(new traingle_1.Traingle());
