import { Shapes} from "./shape";
let traingleobj =new Shapes.Traingle();
console.log(traingleobj.show());