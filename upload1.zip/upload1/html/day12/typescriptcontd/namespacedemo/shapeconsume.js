"use strict";
exports.__esModule = true;
var shape_1 = require("./shape");
var traingleobj = new shape_1.Shapes.Traingle();
console.log(traingleobj.show());
