"use strict";
exports.__esModule = true;
var Shapes;
(function (Shapes) {
    var Traingle = /** @class */ (function () {
        function Traingle() {
        }
        Traingle.prototype.show = function () {
            return "Traingle";
        };
        return Traingle;
    }());
    Shapes.Traingle = Traingle;
    var Square = /** @class */ (function () {
        function Square() {
        }
        Square.prototype.show = function () {
            return "Square";
        };
        return Square;
    }());
    Shapes.Square = Square;
})(Shapes = exports.Shapes || (exports.Shapes = {}));
