export namespace Shapes {
    export class Traingle {
        show(): string {
            return "Traingle";
        }
    }
    export class Square {
        show(): string {
            return "Square";
}
    }
}