import { helloworld } from "./zallo";

describe('helloworld',()=>
{
   it('Hello world',()=>
   {
expect(helloworld()).toEqual("Hello world");
   } );
});