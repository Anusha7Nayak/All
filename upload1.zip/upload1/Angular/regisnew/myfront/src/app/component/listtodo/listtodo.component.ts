import { Component, OnInit } from '@angular/core';
import { Task } from 'src/app/model/task';
import { Router } from '@angular/router';
import { TaskService } from 'src/app/services/task.service';

@Component({
  selector: 'app-listtodo',
  templateUrl: './listtodo.component.html',
  styleUrls: ['./listtodo.component.css']
})
export class ListtodoComponent implements OnInit {

  tasks:Task[];
  constructor(private taskservice:TaskService, 
    private router: Router) { }

  ngOnInit() {
    if(localStorage.getItem("username")!= null){
      this.taskservice.getTasks().subscribe(data=>{
        this.tasks =data ;
      });
    }
    else{
      this.router.navigate(['/login']);
    }
  }
  addtask():void {
    this.router.navigate(['create']);
}
edittask(task: Task):void{
  let result = confirm("Do you really want to edit the task?")
  if(result){
  localStorage.removeItem("editTaskId");
  localStorage.setItem("editTaskId", task.id.toString());
  this.router.navigate(['edit']);
}
}
  deletetask(task: Task):void {
    let result = confirm("Do you really want to delete the task?")
    if(result){
      this.taskservice.deletetask(task.id).subscribe(data=>{
        this.tasks =this.tasks.filter(u=> u!== task);
      });
    }  
     
  }
  


  

  
  
}
  

