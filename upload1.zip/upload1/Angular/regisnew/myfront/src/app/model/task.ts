export class Task {
    id: number;
    Name: string;
    Status: string;
}