import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { EdittodoComponent } from './component/edittodo/edittodo.component';

import { LoginComponent } from './component/login/login.component';
import { ListtodoComponent } from './component/listtodo/listtodo.component';
import { AddtodoComponent } from './component/addtodo/addtodo.component';
import { RegisterComponent } from './component/register/register.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'register',component:RegisterComponent},
  {path:'create',component:AddtodoComponent},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'todo',component:ListtodoComponent},

  {path:'edit',component:EdittodoComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
