import { Injectable } from "@angular/core";
import { Product } from "../model/product";
import { HttpClient } from "@angular/common/http";
import { DataaccessService } from '../dataaccess.service';

@Injectable({
  providedIn: "root"
})
export class ProductService {
  
  getProducts() {
    return this.dataservice.getProduct();
  }

  deleteProduct(id:number) {
    return this.dataservice.deleteProducts(id);
  }
  createProduct(product: Product) {
    return this.dataservice.createProducts(product);
  }
  updateProduct(product: Product) {
    return this.dataservice.updateProducts(product)
  }

  getProductById(id: number) {
    return this.dataservice.getProductsById(id)
  }

  constructor(private dataservice: DataaccessService ) {}
}
