import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { ProductService } from 'src/app/service/product.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  products:Product[];
  p:number=1;
  constructor(private productservice:ProductService,private router:Router) {


  }

  ngOnInit() {
    
    this. productservice.getProducts().subscribe(data=>{
      this.products=data;
      console.log(this.products)
    });
  
  }

    getproduct() {
      if(localStorage.getItem("username")!=null) {
        this. productservice.getProducts().subscribe(data=>{
          this.products=data;
          console.log(this.products)
        });
      

    }
  }
    updateproduct(pro:Product):void{
      localStorage.removeItem("editProductId")
      localStorage.setItem("editProductId",pro.id.toString());
      this.router.navigate(['edit']);
  
    }
    addproduct(): void
  {
    this.router.navigate(['add']);
  }

  
 deleteAll() {
  if(confirm("Do you want to delete All"))
   {
    for(let i=0;i<this.products.length;i++) {
      console.log(this.products[i].id)
      this.productservice.deleteProduct(this.products[i].id).subscribe(()=>{
     this.getproduct();
      })

    }
    }
}


  deleteproduct(pro:Product):void{
    let result=confirm("Do you want to delete user")
    if(result) {
      this.productservice.deleteProduct(pro.id).subscribe(data=>{
        this.products=this.products.filter(u=> u!==pro);
      })
    }
  }

  }

