import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './model/product';


@Injectable({
  providedIn: 'root'
})
export class DataaccessService {
  baseurl: string = "http://localhost:3000/Product";

  getProduct() {
    return this.http.get<Product[]>(this.baseurl);
  }

  deleteProducts(id: number) {
    return this.http.delete<Product[]>(this.baseurl + "/" + id);
  }
  createProducts(product: Product) {
    return this.http.post(this.baseurl, product);
  }
  updateProducts(product: Product) {
    return this.http.put(this.baseurl + "/" + product.id, product);
  }

  getProductsById(id: number) {
    return this.http.get<Product>(this.baseurl + "/" + id);
  }

  constructor(private http: HttpClient) {}
}
