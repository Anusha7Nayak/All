import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseurl:string="http://localhost:2000/users";
getUsers(){
  return this.http.get<User[]>(this.baseurl);
}
// delete users by id
deleteUsers(id:number) {
  return this.http.delete<User[]>(this.baseurl + "/" +id);
 //   alert('name to be deleted' +name);
   
 
}
createuser(user:User){
  return this.http.post(this.baseurl,user);
}
//modify user
updateUser(user:User){
  return this.http.put(this.baseurl+'/'+user.id, user);

}

getUsersById(id:number) {
  return this.http.get<User>(this.baseurl+"/"+id)
}
  constructor(private http:HttpClient) { }
}
