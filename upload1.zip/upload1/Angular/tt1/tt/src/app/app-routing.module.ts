import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { ListUserComponent } from './component/list-user/list-user.component';
import { AdduserComponent } from './component/adduser/adduser.component';
import { EditComponent } from './component/edit/edit.component';

const routes: Routes = [
  {path: '',component: HomeComponent},
  {path: 'home',component: HomeComponent},
  {path: 'login',component: LoginComponent},
  {path:'list-user', component:ListUserComponent},
  {path:'adduser', component:AdduserComponent},
  {path:'edit', component:EditComponent}
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
