import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {
users:User[];
  constructor(private userservice:UserService,private router:Router) { }

  ngOnInit() {
if(localStorage.getItem("username")!=null) {
  this.userservice.getUsers().subscribe(data=>{
    this.users=data;
  });

  //new
  
  
}
else{
  this.router.navigate(['/login']);
}

  }
  deleteUsers(use:User):void{
    let result=confirm("Do you want to delete user")
    if(result) {
      this.userservice.deleteUsers(use.id).subscribe(data=>{
        this.users=this.users.filter(u=> u!==use);
      })
    }
  }
  updateUser(use:User):void{
    localStorage.removeItem("editUserId")
    localStorage.setItem("editUserId",use.id.toString());
    this.router.navigate(['edit']);

  }
  adduser(): void
  {
    this.router.navigate(['adduser']);
  }
 
  logOutUser():void {
    if(localStorage.getItem("username")!=null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }
}
