import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { FormBuilder,Validators,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  editForm:FormGroup;
  submitted:boolean=true;

  constructor(private formbuilder:FormBuilder,private router:Router, 
    private userservice:UserService) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null) {
      let userId=localStorage.getItem("editUserId");
      if(!userId){
        alert("invalid action");
        this.router.navigate(['list-user']);
        return;
      }
    
    this.editForm=this.formbuilder.group({
      id:[],
      firstname:['',Validators.required],
      lastname:['',Validators.required],
      email:['',Validators.required]

    });

    this.userservice.getUsersById(+userId).subscribe(data=>{
      this.editForm.setValue(data)
    });
  }

  else {
    this.router.navigate(['/login']);
  }
}
  
  
   onsubmit(){
     this.submitted=true;
    if(this.editForm.invalid){
      return;
     }
     this.userservice.updateUser(this.editForm.value)
     .subscribe(data=> {alert(this.editForm.value.firstname + "" +'record edited')
  
     });
  
   
     this.router.navigate(['list-user']);
   }
   }

