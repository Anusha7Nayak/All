import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { ListUserComponent } from './component/list-user/list-user.component';
import { HttpClientModule } from '@angular/common/http';
import { AdduserComponent } from './component/adduser/adduser.component';
import { EditComponent } from './component/edit/edit.component';
import { ParentComponent } from './component/parent/parent.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    ListUserComponent,
    AdduserComponent,
    EditComponent,
    ParentComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
