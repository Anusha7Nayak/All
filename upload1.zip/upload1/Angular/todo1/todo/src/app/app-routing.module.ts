import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { TodoListComponent } from './todo-list/todo-list.component';
import { EditFormComponent } from './edit-form/edit-form.component';
import { AddFormComponent } from './add-form/add-form.component';


const routes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'login', component: LoginFormComponent},
  { path: 'todo-list', component: TodoListComponent},
  { path: 'edit', component: EditFormComponent},
  { path: 'add', component: AddFormComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
