var express=require('express');
var mongoose=require('mongoose');
//import router file
const route=require('./router/router')
var cors= require('cors');

mongoose.connect('mongodb://localhost:27017/mydb');
mongoose.connection.on('connected',()=>{
    console.log("mongodb connected to 27017");
})
// router.get();
// router.post();
// router.delete();
var app=new express()
app.get('/',(req,res)=>{
    res.send("hello from root path")
});
// add middlewarw to parse the data

app.use(cors());
app.use(express.json());
// add an middleware to configure routes
app.use('/api',route);
const port=700;
app.listen(port,function()
{
console.log('server started');
})
