const mongoose=require('mongoose');
const itemsschema=mongoose.Schema({
    itemname:{
        type:String,
        required:false,

    },
    itemquantity:{
        type:Number,
        required:false,
    },
 itembought:{
     type:Boolean,
     required:false,
 },
});
const item=module.exports=mongoose.model('items',itemsschema)