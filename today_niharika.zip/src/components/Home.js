import React, { Component } from "react";

export class Home extends Component {
  render() {
    return (
      <div className="app">
        <h1>Welcome to online Shopping Page</h1>
        <img src={require("./image.jpg")} />
      </div>
    );
  }
}

export default Home;
