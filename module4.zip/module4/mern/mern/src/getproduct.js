import React, { Component } from 'react';
import axios from 'axios';


export default class Get extends Component {

  constructor(props) {
      super(props);
      this.state = {serverports: []};
    }
    baseurl = "http://localhost:5000/serverport";
    getproducts = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ serverports: response.data })
            console.log(response.data._id)
        });
    }


    deleteProduct(id){
        alert(' id:' + id)
        axios.delete( "http://localhost:5000/serverport/"+id).then((res) => {
            this.getproducts();
        },
            (err) => {
                this.setState({ errors: err })
            })
    }
  
    componentDidMount(){
       this.getproducts();
      
      
    }
   
    render() {
    
      return (
          <table  className="table table-hover table-stipped">
         <thead>
                <tr>
                  <td>Name</td>
                  <td>Price</td>
                </tr>
         </thead>
         
          {this.state.serverports.map((object)=> <tbody>
         
            <tr>
              
              <td>{object.productname}</td>
              <td>{object.productprice}</td>
              <td> <button className="btn btn-danger" 
              onClick={(e)=> this.deleteProduct(object._id)}>X</button>
                </td>
            </tr>
            </tbody>
       
        )}
     
        </table>
      );
    }
  }