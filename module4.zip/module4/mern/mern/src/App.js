import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Create from './createproduct';
import Get from './getproduct';

class App extends Component {
  render() {
    return (
      <Router>
      <div className="container">
        <h2>Add products</h2>
        <ul>
          <li><Link to={'/create'}>Addproducts</Link></li>
          <li><Link to={'/Get'}>showallproducts</Link></li>
        </ul>
        <hr />
        <Switch>
            <Route exact path='/create' component={ Create } />
            <Route path='/Get' component={ Get } />
        </Switch>
      </div>
    </Router>
    );
  }
}

export default App;
