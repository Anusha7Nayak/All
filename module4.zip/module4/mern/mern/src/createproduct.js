import React, { Component } from 'react';
import axios from 'axios';

export default class Create extends Component {

    constructor(props) {
        super(props);
        this.onChangeHostName = this.onChangeHostName.bind(this);
        this.onChangePrice = this.onChangePrice.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
           productname: '',
            productprice: ''
        }
    }
    // id(e){
    //     this.setState({
    //         productid: e.target.value
    //     });  
    // }
    onChangeHostName(e) {
        this.setState({
            productname: e.target.value
        });
    }
    onChangePrice(e) {
        this.setState({
            productprice: e.target.value
        });
    }
    onSubmit(e) {
        e.preventDefault();
        const serverport = {
            // productid:this.state.productid,
            productname: this.state.productname,
            productprice: this.state.productprice
        }
        axios.post('http://localhost:5000/serverport/add', serverport)
        //.then(res => console.log(res.data));
        .then(function (response) {
            console.log(response.data);
           alert(response.data);
          });
        this.setState({
            // productid:'',
            productname: '',
            productprice: ''
        });
    }

    render() {
        
        return (
            <div style={{marginTop: 50}}>
            <h3>Add New Product</h3>
            <form onSubmit={this.onSubmit}>
            {/* <div className="form-group">
                    <label>ProductId: </label>
                    <input type="text" className="form-control" value={this.state.productid}  onChange={this.id}/>
                </div> */}
                <div className="form-group">
                    <label>Productname </label>
                    <input type="text" className="form-control" value={this.state.productname}  onChange={this.onChangeHostName}/>
                </div>
                <div className="form-group">
                    <label>Productprice : </label>
                    <input type="text" className="form-control" value={this.state.productprice}  onChange={this.onChangePrice}/>
                </div>
                <div className="form-group">
                    <input type="submit" value="Add Node server" className="btn btn-primary"/>
                </div>
            </form>
        </div>
        )
    }
}