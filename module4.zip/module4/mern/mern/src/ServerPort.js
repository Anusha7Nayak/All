const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Define collection and schema for ServerPort
const ServerPort = new Schema(
  {
    productname: {
      type: String
    },

    productprice: {
      type: Number
    }
  },
  {
    collection: "mernproducts1"
  }
);

module.exports = mongoose.model("ServerPort", ServerPort);
